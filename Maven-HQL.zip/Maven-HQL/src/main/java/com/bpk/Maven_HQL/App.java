package com.bpk.Maven_HQL;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;
import com.bpk.Maven_HQL.model.Product;
public class App 
{
    public static void main( String[] args )
    {
        Configuration cfg=new Configuration();
        cfg.configure("hibernate.cfg.xml");
        SessionFactory sf=cfg.buildSessionFactory();
        Session s=sf.openSession();
        Product p=new Product();
        
        p.setId(30135);
        p.setName("Pavan");
        
        s.save(p);
        Transaction tx=s.beginTransaction();
        tx.commit();
        sf.close();
        s.close();
    }
}
